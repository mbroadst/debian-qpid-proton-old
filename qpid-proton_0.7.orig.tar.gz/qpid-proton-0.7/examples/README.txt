This directory contains example applications that use the Proton library.

  messenger/ - simple examples using the messenger API in a variety of
               languages (C, perl, php, python, ruby)
